from flask import Flask, request, jsonify
import random
from flask_cors import CORS

application = Flask(__name__)
CORS(application)


def generate_deck():
    suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
    values = ['2', '3', '4', '5', '6', '7', '8',
              '9', '10', 'Jack', 'Queen', 'King', 'Ace']
    return [{'suit': suit, 'value': value} for suit in suits for value in values]


@application.route('/cards/', methods=['GET'])
def get_cards():
    quantity = request.args.get('quantity', default=1, type=int)
    deck = generate_deck()
    random.shuffle(deck)
    return jsonify(deck[:quantity])


if __name__ == '__main__':
    application.run(debug=True)
